"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const protractor_1 = require("protractor");
describe('TODO', () => {
    const URL = "http://todomvc.com/examples/angularjs/#/";
    it('should go to a valid URL', () => {
        protractor_1.browser.get(URL);
        // expect(1)
        expect(protractor_1.browser.baseUrl.includes('.com'));
        // expect(browser.getCurrentUrl()).toContain(URL);
    });
});

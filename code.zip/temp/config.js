"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.config = {
    directConnect: true,
    specs: [
        "spec/**/*.spec.js"
    ],
    capabilities: {
        browserName: 'firefox',
        'moz:firefoxOptions': {
            args: ["--headless"]
        }
    }
};

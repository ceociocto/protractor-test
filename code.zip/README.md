# protractor-min-code
This is a sample project that I found to be the most minimalistic. Feel free to use as a npm project template for your protractor project.

To run, copy the repo and then in root directory:
``` 
npm install
npm run before-test
npm run test
```

If tyou want to understand this code more, visit [this article](https://medium.com/@jacekgraj/a-minimal-protractor-project-setup-with-detailed-explanation-735eadcde3e4) and feel free to comment on it!
